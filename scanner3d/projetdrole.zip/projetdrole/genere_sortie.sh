#!/bin/sh
convert display/onsauvegarde/*.png sortie.gif