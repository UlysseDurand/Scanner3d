POUR GENERER L'ENTREE
-mettre le fichier obj voulu dans /generate/
-choisir un nombre d'images n et mettre dans /generate/generate.pde la bonne valeur de nomfichier et de n   
-changer si besoin les valeurs dans /generate/generate.pde de agrandir, decaly, et les paramètres de size()
-lancer /generate.generate.pde à l'aide de Processing
-lancer generer_entree.sh

POUR GENERER LA SORTIE
-mettre les bonnes valeurs de n, (w,h) (largeur et hauteur des images) dans main.py
-lancer main.py avec python
-lancer display/display.pde avec Processing
-lancer genere_sortie.sh
